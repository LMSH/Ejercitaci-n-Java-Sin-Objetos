package Ejercitacion1;

import java.util.Scanner;

/**
 * Created by andres on 31/03/16.
 */
public class Ejercicio2 {

    public static void main(String[] args){
        //Enunciado -- Declarar variables:  "unNumeroA" de tipo INTEGER
        //                                  "unNumeroB" de tipo DOUBLE
        //                                  "unaCadenaDeTexto" de tipo STRING
        //Luego, imprimir por pantalla:  el valor de cada variable
        //                               la suma de "unNumeroA" + "unNumeroB"
        //                               la diferencia entre "unNumeroA" - "unNUmeroB"

        //Comenzar a escribir código acá

        Integer unNumeroA = 2;
        Double unNumeroB = 2.3;
        String unNumeroC = "Perro";

        System.out.println(unNumeroA + unNumeroB);
        System.out.println(unNumeroA-unNumeroB);
        System.out.println(unNumeroC);

    }
}

